#==============================
# Christian Duncan
# CSC345: Computer Graphics
# Spring 2021
# Edited by: Shannon Luker, Reese DelGrande, Gabby Licht
# Description:
#   Demonstrates use of glu properties to set up a wireframe
#   scene that animates a car and has navigation.
#==============================

import sys
from utils import *

try:
    import OpenGL as ogl
    try:
        import OpenGL.GL   # this fails in <=2020 versions of Python on OS X 11.x
    except ImportError:
        print('Drat, patching for Big Sur')
        from ctypes import util
        orig_util_find_library = util.find_library
        def new_util_find_library( name ):
            res = orig_util_find_library( name )
            if res: return res
            return '/System/Library/Frameworks/'+name+'.framework/'+name
        util.find_library = new_util_find_library
except ImportError:
    pass

from OpenGL.GLUT import *
from OpenGL.GLU import *
from OpenGL.GL import *

# These parameters define the camera's lens shape
CAM_NEAR = 0.01
CAM_FAR = 1000.0
CAM_ANGLE = 10.0

# These parameters define simple animation properties
MIN_STEP = 0.1
DEFAULT_STEP = 0.001
ANGLE_STEP = DEFAULT_STEP
FPS = 60.0
DELAY = int(1000.0 / FPS + 0.5)

# Global (Module) Variables (ARGH!)
winWidth = 1000
winHeight = 1000
name = b'A Simple Car'
animate = True
angleMovement = 0
perspectiveMode = True
moveCar = False
carDistance = 0
CAR_SPEED = 0.05                           
WHEEL_SPEED = 0.5                           
wheelAngle = 0
maxDistance = 20
eye = Point(0, 10, -70)
look = Point(0, 0, 0)
lookD = Vector(Point(0, 0, -2))
up = Vector(Point(0, 1, 0))  # Usually what you want unless you want a tilted camera

def main():
    # Create the initial window
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB)
    glutInitWindowSize(winWidth, winHeight)
    glutInitWindowPosition(100,100)
    glutCreateWindow(name)

    init()

    # Setup the callback returns for display and keyboard events
    glutDisplayFunc(display)
    glutKeyboardFunc(keyboard)
    glutSpecialFunc(specialKeys)
    glutReshapeFunc(reshape)   # Enable to allow reshaping...
    glutTimerFunc(0, timer, DELAY)

    # Enters the main loop.   
    # Displays the window and starts listening for events.
    glutMainLoop()
    return

# Any initialization material to do...
def init():
    global tube, ball
    tube = gluNewQuadric()
    gluQuadricDrawStyle(tube, GLU_LINE)


# Callback function used to display the scene
# Currently it just draws a simple polyline (LINE_STRIP)
def display():
    # Set the viewport to the full screen
    glViewport(0, 0, winWidth, winHeight)

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    # Set view to Perspective Proj. (angle, aspect ratio, near/far planes)
    if perspectiveMode:
        # Set view to Perspective Proj. (angle, aspect ratio, near/far planes)
        gluPerspective(CAM_ANGLE, winWidth/winHeight, CAM_NEAR, CAM_FAR)
    else:
        glOrtho(-winWidth/40, winWidth/40, -winHeight/40, winHeight/40, -100, 100)
    
    # Clear the Screen
    glClearColor(1.0, 1.0, 1.0, 1.0)
    glClear(GL_COLOR_BUFFER_BIT)

    # And draw the "Scene"
    glColor3f(1.0, 1.0, 1.0)
    drawScene()

    # And show the scene
    glFlush()
    glutSwapBuffers()  # needed for double buffering!

# Timer: Used to animate the scene when activated:
def timer(alarm):
    glutTimerFunc(0, timer, DELAY)   # Start alarm clock again
    if animate:
        # Advance to the next frame
        advance()
        glutPostRedisplay()

# Advance the scene one frame
def advance():
    global carDistance, moveCar, wheelAngle, maxDistance, CAR_SPEED, WHEEL_SPEED
    if moveCar:
        carDistance += CAR_SPEED #Moves car forward with wheels moving
        wheelAngle += WHEEL_SPEED
        if carDistance >= maxDistance: #Sets a max distance for car to move to
            CAR_SPEED = -CAR_SPEED
            WHEEL_SPEED = -WHEEL_SPEED
        elif carDistance <= -maxDistance: #Sets a minimum distance for the car to move to
            CAR_SPEED = -CAR_SPEED
            WHEEL_SPEED = -WHEEL_SPEED
                            
def specialKeys(key, x, y):
    global angleMovement, carDistance
    if key == GLUT_KEY_LEFT:
        angleMovement += 1
        glutPostRedisplay()
    elif key == GLUT_KEY_RIGHT:
        angleMovement -= 1
        glutPostRedisplay()
    elif key == GLUT_KEY_UP:
        carDistance += 1
        glutPostRedisplay()
    elif key == GLUT_KEY_DOWN:
        carDistance -= 1
        glutPostRedisplay()

# Callback function used to handle any key events
# Currently, it just responds to the ESC key (which quits)
# key: ASCII value of the key that was pressed
# x,y: Location of the mouse (in the window) at time of key press)
def keyboard(key, x, y):
    if ord(key) == 27:  # ASCII code 27 = ESC-key
        glutLeaveMainLoop()
    elif ord(key) == ord('p'):
        global perspectiveMode
        print("DEBUG: Toggling perspective mode")
        perspectiveMode = not perspectiveMode
        glutPostRedisplay()
    elif ord(key) == ord(' '):
        global animate
        animate = not animate
    elif key == b'f':
        global moveCar
        moveCar = not moveCar 

        
# Callback function used to handle window reshaping events
def reshape(w, h):
    global winWidth, winHeight
    winWidth = w
    winHeight = h
    glutPostRedisplay()  # May need to call a redraw...

def drawScene():
    """
    * drawScene:
    *    Draws a simple scene with a few shapes
    """
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    # Place the camera
    gluLookAt(eye.x, eye.y, eye.z,                               # Camera's origin
    # eye.x + lookD.dx, eye.y + lookD.dy, eye.z + lookD.dz,      # Camera's look at direction
              look.x, look.y, look.z,                            # Camer's look at point              
              up.dx, up.dy, up.dz)                               # Camera's relative "up" orientation
    
    # Now transform the world
    glRotated(angleMovement, 0, 1, 0)  # Spin around y-axis
    glColor3f(0, 0, 0)
    draw() 

# Draw the entire scene
def draw():
    glPushMatrix()
    drawCone()
    glPopMatrix()
    glPushMatrix()
    glTranslated(0, 0, carDistance) #Allows car to move
    drawCar()
    glPopMatrix()

def drawCone():
    #Cone 1
    glPushMatrix()
    glRotated(-90, 1, 0, 0)
    glScaled(0.2, 0.2, 0.2)
    glTranslated(-4, 0, 0)
    gluCylinder(tube, 3, 1, 15, 10, 10)  # quadric, base r, top r, height (along z), slices (around), stacks (towards height)
    glPopMatrix()

    #Cone 2
    glPushMatrix()
    glRotated(-90, 1, 0, 0)
    glScaled(0.2, 0.2, 0.2)
    glTranslated(25, 0, 0)
    gluCylinder(tube, 3, 1, 15, 10, 10)  # quadric, base r, top r, height (along z), slices (around), stacks (towards height)
    glPopMatrix()

#Car body
def drawBox():
    #Bottom square
    glPushMatrix()
    glRotated(-90, 1, 0, 0)
    glTranslated(1, 0, 0)
    glBegin(GL_LINE_LOOP)
    glVertex3f(0, 0, 0) #bottom left point
    glVertex3f(2, 0, 0) #bottom right point
    glVertex3f(2, 5, 0) #top right point
    glVertex3f(0, 5, 0) #top left point
    glEnd()
    glPopMatrix()
    
    #Line 1
    glPushMatrix()
    glTranslated(1, 0, 0)
    glBegin(GL_LINES);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 1, 0);
    glEnd();
    glPopMatrix()

    #Line 2
    glPushMatrix()
    glTranslated(3, 0, 0)
    glBegin(GL_LINES);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 1, 0);
    glEnd();
    glPopMatrix()

    #Line 3
    glPushMatrix()
    glTranslated(3, 0, -5)
    glBegin(GL_LINES);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 1, 0);
    glEnd();
    glPopMatrix()

    #Line 4
    glPushMatrix()
    glTranslated(1, 0, -5)
    glBegin(GL_LINES);
    glVertex3f(0, 0, 0);
    glVertex3f(0, 1, 0);
    glEnd();
    glPopMatrix()

    #Top square
    glPushMatrix()
    glRotated(-90, 1, 0, 0)
    glTranslated(1, 0, 1)
    glBegin(GL_LINE_LOOP)
    glVertex3f(0, 0, 0) #bottom left point
    glVertex3f(2, 0, 0) #bottom right point
    glVertex3f(2, 5, 0) #top right point
    glVertex3f(0, 5, 0) #top left point
    glEnd()
    glPopMatrix()

#Box on top of car body
def drawTopBox():
    glPushMatrix()
    glScaled(0.4, 0.4, 0.4)
    glTranslated(2.5, 2.5, -4)
    glRotated(-90, 0, 1, 0)
    drawBox()
    glPopMatrix()

def drawWheels():
    #Wheel 1
    glPushMatrix()
    glTranslated(0.6, 0, -0.5)         
    glRotated(90, 0, 1, 0)  
    glScaled(0.2, 0.2, 0.2)
    glRotated(wheelAngle, 0, 0, 1) #Rotates the wheels as the car moves
    gluCylinder(tube, 2, 2, 2, 10, 10)  # quadric, base r, top r, height (along z), slices (around), stacks (towards height)
    glPopMatrix()

    #Wheel 2
    glPushMatrix()
    glTranslated(3, 0, -0.5)         
    glRotated(90, 0, 1, 0)  
    glScaled(0.2, 0.2, 0.2)
    glRotated(wheelAngle, 0, 0, 1)
    gluCylinder(tube, 2, 2, 2, 10, 10)  # quadric, base r, top r, height (along z), slices (around), stacks (towards height)
    glPopMatrix()

    #Wheel 3
    glPushMatrix()
    glTranslated(3, 0, -3.5)         
    glRotated(90, 0, 1, 0)  
    glScaled(0.2, 0.2, 0.2)
    glRotated(wheelAngle, 0, 0, 1)
    gluCylinder(tube, 2, 2, 2, 10, 10)  # quadric, base r, top r, height (along z), slices (around), stacks (towards height)
    glPopMatrix()

    #Wheel 4
    glPushMatrix()
    glTranslated(0.6, 0, -3.5)         
    glRotated(90, 0, 1, 0)  
    glScaled(0.2, 0.2, 0.2)
    glRotated(wheelAngle, 0, 0, 1)
    gluCylinder(tube, 2, 2, 2, 10, 10)  # quadric, base r, top r, height (along z), slices (around), stacks (towards height)
    glPopMatrix()

def drawCar():   
    glPushMatrix()
    drawBox()
    drawTopBox()
    drawWheels()
    glPopMatrix()
    
#=======================================
# Direct OpenGL Matrix Operation Examples
#=======================================
def printMatrix():
    """
    Prints out the Current ModelView Matrix
    The problem is in how it is stored in the system
    The matrix is in COL-major versus ROW-major so
    indexing is a bit odd.
    """
    m = glGetFloatv(GL_MODELVIEW_MATRIX)
   
    for row in range(4):
        for col in range(4):
            sys.stdout.write('{0:6.3f} '.format(m[col][row]))
        sys.stdout.write('\n')
    

if __name__ == '__main__': main()
