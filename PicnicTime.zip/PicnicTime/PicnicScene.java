/********************
 * Picnic Time Scene
 * Author: Shannon Luker, Reese DelGrande, Gabby Licht
 * Spring 21: CSC345
 *
 * Based off the GraphicsStarter2D.java file from Eck's text and Christian Duncan's HierarchyScene.java
 * 
 * This class illustrates a picnic scene using Java's
 * Graphics2D class
 ********************/

import java.awt.*;        // import statements to make necessary classes available
import java.awt.geom.*;
import javax.swing.*;
import java.awt.event.*;

public class PicnicScene extends JPanel {
    /**
     * This main() routine makes it possible to run the class PicnicScene
     * as an application.
     */
    public static void main(String[] args) {
        JFrame window;
        window = new JFrame("Picnic Time");
        PicnicScene panel = new PicnicScene();
        window.setContentPane(panel); // Show an instance of this class in main window pane
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // End program when window closes.
        window.pack();  // Set window size based on the preferred sizes of its contents.
        window.setResizable(false); // Don't let user resize window.
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();

        // Set up the animation timer and operation
        Timer animationTimer;  // A Timer that will emit events to drive the animation.
        final long startTime = System.currentTimeMillis();
        animationTimer = new Timer(16, new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                panel.updateScene(16); // Advance to the "next" frame.
                panel.repaint();
            }
        });


        // Center window on screen.
        window.setLocation((screen.width - window.getWidth())/2, (screen.height - window.getHeight())/2);
        window.setVisible(true); // Open the window, making it visible on the screen.
        animationTimer.start();  // Start the timer going.
    }
    
    private float pixelSize;  // This is the measure of a pixel in the coordinate system

    
    public PicnicScene() {
        setPreferredSize(new Dimension(1000,1000) ); // Set size of drawing area, in pixels.
    }
    
    /**
     * The paintComponent method draws the content of the JPanel.
     */

    protected void paintComponent(Graphics g) {

        Graphics2D g2 = (Graphics2D) g.create();
        
        /* Turn on antialiasing in this graphics context, for better drawing.
         */
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        /* Fill in the entire drawing area with a blue background.
         */
        g2.setPaint(new Color(56, 198, 254));
        g2.fillRect(0,0,getWidth(),getHeight()); // From the old graphics API!
        

        applyapplyWindowToViewportTransformation(g2, -15, 15, -15, 15, true);
        

        drawScene(g2);
    }

    /**
     * Draw the scene
     */
    private void drawScene(Graphics2D g2) {

        // Scene version 1
        AffineTransform cs = g2.getTransform();   // Save current "coordinate system" transform
        g2.scale(1,1);  // No scaling yet, but setting it up to make a tad bigger
        drawMainScene(g2);
    }

    private void drawMainScene(Graphics2D g2) {
        
        drawSun(g2);
        
        // Draws grass
        g2.setPaint(new Color(0, 255, 0));  // Set color to green
        g2.fill(new Rectangle2D.Double(-500, -500, 1000, 500)); // x, y, width, height

        drawLake(g2);

        g2.setPaint(Color.WHITE);
        drawBlanketScene(g2);
        drawBird(g2);

        drawTree(g2);

        g2.translate(-6,-7);
        g2.scale(1.5,1.5);
        drawSeeSaw(g2);

    }

    //Variables used in drawSun that will be updated
    private double sunAlpha = 100;
    private double sunRadius = 2;
    private double sunDR = 0.3;

    //Variables used in drawBird that will be updated
    private double birdOriginX = 0;
    private double birdOriginY = 8;
    private double birdDX = -0.05;
    private double birdDY = 0.005;
    private double wingTipX = 3;
    private double wingTipY = 0.75;
    private double wingTipDY = 0.05;


    private void updateScene(long dt) {
    	//Updates size of sun
        sunDR += ((Math.random() - 0.5) * 0.01);
    	if (sunDR < 0.1) sunDR = 0.1;
    	else if (sunDR > 1) sunDR = 1;
        //Updates alpha value (opacity) of sun
    	sunAlpha += ((Math.random() - 0.5) * 5);
    	if (sunAlpha < 50) sunAlpha = 50;
    	else if (sunAlpha > 200) sunAlpha = 200;

    	//Determines placement of bird in the x direction
        birdOriginX +=  birdDX;
    	birdOriginY += birdDY;
    	if (birdOriginX < -10) {
    		birdOriginX = -10;
    		birdDX = -birdDX;
    	}
    	else if (birdOriginX > 10) {
    		birdOriginX = 10;
    		birdDX = -birdDX;
    	}
    	if (birdOriginY < 0) {
    		birdOriginY = 0;
    		birdDY = -birdDY;
    	}
    	else if (birdOriginY > 15) {
    		birdOriginY = 15;
    		birdDY = -birdDY;
    	}
        //Determines birds wing's flapping
    	wingTipY += wingTipDY;
    	if (wingTipY < -2) {
    		wingTipY = -2;
    		wingTipDY = -wingTipDY;
    	}
    	else if (wingTipY > 1) {
    		wingTipY = 1;
    		wingTipDY = -wingTipDY;
    	}
    	
        //Changes the seesaw angle back and forth between maximum and minimum values
        seesawAngle += seesawDelta;   // Update the angle
        if (seesawAngle >= MAX_TILT) {
            seesawAngle = MAX_TILT;
            seesawDelta = -seesawDelta; //Change direction
        }
        else if (seesawAngle <= MIN_TILT) {
            seesawAngle = MIN_TILT;
            seesawDelta = -seesawDelta; //Change direction
        }
    }

    private void drawSun(Graphics2D g2) {
    	AffineTransform cs = g2.getTransform();
    	g2.translate(7, 14);
        g2.setPaint(Color.YELLOW); // Set color to yellow
        
        g2.fill(new Ellipse2D.Double(-sunRadius, -sunRadius, sunRadius * 2, sunRadius * 2)); //Fills sun with speicifed radius 
        g2.setPaint (new Color(255,255,0,(int)sunAlpha));
        double sR = (sunRadius + sunDR);
        g2.fill(new Ellipse2D.Double(-sR, -sR, sR * 2, sR * 2)); 
        
        g2.setTransform(cs);
    }

    private void drawBird(Graphics2D g2) {
    	AffineTransform cs = g2.getTransform();
    	g2.translate(birdOriginX, birdOriginY);
    	g2.scale(0.25, 0.25);
    	g2.setStroke(new BasicStroke(0.4f)); //sets stroke of lines
    	g2.setPaint(Color.BLACK);
    	
        Path2D poly = new Path2D.Double();
        poly.moveTo(-wingTipX, wingTipY);
        poly.quadTo(-wingTipX / 2, wingTipY * 1.3, 0, -1);
        poly.quadTo(wingTipX / 2, wingTipY * 1.3, wingTipX, wingTipY);
        
        g2.draw(poly);
    	g2.setTransform(cs);
    }

    private void drawLake(Graphics2D g2) {
        AffineTransform cs = g2.getTransform();
        g2.scale(0.04, 0.04);
        
        Path2D poly = new Path2D.Double();
        poly.moveTo(-250,0);
        poly.quadTo(-250, -125, 0,-125); //curved lines that build lake shape
        poly.quadTo(250, -125, 250, 0);
        poly.closePath();
        
        g2.setPaint(new Color(0, 0, 255) ); // blue
        g2.fill(poly);
        g2.setTransform(cs);
    }

    private double personTorso = 1.0;

    private double personHeadSize = 0.3; //radius of the head

    private double legLength = 0.9;

    private double armLength = 0.45;

    private void drawPerson(Graphics2D g2){
         AffineTransform cs = g2.getTransform();
         g2.fill(new Ellipse2D.Double(-personHeadSize, personTorso, 2 * personHeadSize, 2 * personHeadSize));
         g2.setStroke(new BasicStroke(3 * pixelSize));
         g2.setPaint(Color.BLACK);
         g2.draw(new Ellipse2D.Double(-personHeadSize, personTorso, 2 * personHeadSize, 2 * personHeadSize));

         Path2D body = new Path2D.Double();
         body.moveTo(0, personTorso);
         body.lineTo(0,0);
         body.lineTo(0.2, -legLength/2);
         body.lineTo(0, -legLength);

         body.moveTo(0, 0.75 * personTorso);
         body.lineTo(armLength, 0.75 * personTorso);
         g2.scale(-1, 1);
         g2.draw(body);

         g2.setTransform(cs);
    }

    private void drawPerson2(Graphics2D g2){ //person on left of seesaw
         AffineTransform cs = g2.getTransform();
         g2.setPaint(Color.WHITE);
         g2.fill(new Ellipse2D.Double(-personHeadSize, personTorso, 2 * personHeadSize, 2 * personHeadSize));
         g2.setStroke(new BasicStroke(3 * pixelSize));
         g2.setPaint(Color.BLACK);
         g2.draw(new Ellipse2D.Double(-personHeadSize, personTorso, 2 * personHeadSize, 2 * personHeadSize));

         Path2D body = new Path2D.Double();
         body.moveTo(0, personTorso);
         body.lineTo(0,0);
         body.lineTo(-0.2, -legLength/2);
         body.lineTo(0, -legLength);

         body.moveTo(0, 0.75 * personTorso);
         body.lineTo(-armLength, 0.75 * personTorso);
         g2.scale(-1, 1);
         g2.draw(body);

         g2.setTransform(cs);
    }

    //Draws blanket with a person on it
    private void drawBlanketScene(Graphics2D g2) {
         AffineTransform cs = g2.getTransform();
         g2.translate(6.5,-6);
         g2.shear(1,0);
         g2.scale(0.5, 0.5);
         g2.setPaint(new Color(211, 193, 161));
         g2.fillRect(-2, -2, 7, 7);
         g2.setPaint(Color.WHITE);
         drawPerson(g2);

         //Briefcase
         g2.translate(3, 3);
         g2.fillRect(-1, -1, 2, 2);
         g2.setPaint(new Color(150, 75, 0));

         g2.setTransform(cs);
    }

    private double treeRadius = 2.5;
    
    private void drawTreeTop (Graphics2D g2){
        AffineTransform cs = g2.getTransform();  // Save C.S. state
        g2.translate(-12,1);
        g2.setColor(new Color(0, 150, 0));
        g2.fill(new Ellipse2D.Double(-treeRadius, -treeRadius, treeRadius * 2, treeRadius *2));

        AffineTransform cs2 = g2.getTransform();
        g2.translate(24.5,.09);
        g2.setColor(new Color(0, 150, 0));
        g2.fill(new Ellipse2D.Double(-treeRadius, -treeRadius, treeRadius * 2, treeRadius *2));

        g2.setTransform(cs2);
        g2.setTransform(cs);
    }
    
    private void drawTreeTrunk(Graphics2D g2){
        AffineTransform cs = g2.getTransform();
        g2.translate(-13,-6);
        g2.setColor(new Color(139, 69, 19)); 
        g2.fill(new Rectangle2D.Double(0, 0, 2, 5));
        
        AffineTransform cs2 = g2.getTransform();  // Save C.S. state
        g2.translate(24.5,0.15);
        g2.setColor(new Color(139, 69, 19)); 
        g2.fill(new Rectangle2D.Double(0, 0, 2, 5));
            
        g2.setTransform(cs2);
     
        g2.setTransform(cs);       // Restore previous C.S. state
    }

    private void drawTree (Graphics2D g2){
        drawTreeTrunk(g2);
        drawTreeTop(g2);
    }

    private double seesawAngle = 0; 
    private double seesawDelta = 0.02; //How much its moving
    private double MAX_TILT = (Math.PI/6); //Maximum angle
    private double MIN_TILT = (-Math.PI/6); //Minimum angle

    private void drawSeeSaw(Graphics2D g2){
        AffineTransform cs = g2.getTransform();
        g2.setPaint(new Color(72, 72, 42));
        Path2D triangle = new Path2D.Double();
        triangle.moveTo(-1, -1);
        triangle.lineTo(0,0);
        triangle.lineTo(1,-1);
        triangle.closePath();
        g2.fill(triangle);
        g2.setTransform(cs);

        g2.rotate(seesawAngle); //rotates the coordinate system
        g2.setPaint(new Color(148, 0, 211));
        Path2D seesaw = new Path2D.Double();
        seesaw.moveTo(-3, 0);
        seesaw.lineTo(3,0);
        g2.draw(seesaw);
        g2.setTransform(cs);

        g2.translate(-3,0);
        g2.rotate(seesawAngle);
        g2.scale(-1,1);
        g2.setPaint(Color.WHITE);
        drawPerson(g2);
        g2.getTransform();
        g2.setTransform(cs);
        
        g2.translate(3,0);
        g2.rotate(seesawAngle);
        g2.scale(-1,1);
        drawPerson2(g2);
        g2.getTransform();
    }
    
    
    /**
     * Applies a coordinate transform to a Graphics2D graphics context.  The upper
     * left corner of the viewport where the graphics context draws is assumed to
     * be (0,0).  The coordinate transform will make a requested view window visible
     * in the drawing area.  The requested limits might be adjusted to preserve the
     * aspect ratio.
     *     This method sets the value of the global variable pixelSize, which is defined as the
     * maximum of the width of a pixel and the height of a pixel as measured in the
     * coordinate system.  (If the aspect ratio is preserved, then the width and 
     * height will agree.
     * @param g2 The drawing context whose transform will be set.
     * @param left requested x-value at left of drawing area.
     * @param right requested x-value at right of drawing area.
     * @param bottom requested y-value at bottom of drawing area; can be less than
     *     top, which will reverse the orientation of the y-axis to make the positive
     *     direction point upwards.
     * @param top requested y-value at top of drawing area.
     * @param preserveAspect if preserveAspect is false, then the requested view window
     *     rectangle will exactly fill the viewport; if it is true, then the limits will be
     *     expanded in one direction, horizontally or vertically, if necessary, to make the
     *     aspect ratio of the view window match the aspect ratio of the viewport.
     *     Note that when preserveAspect is false, the units of measure in the horizontal 
     *     and vertical directions will be different.
     */
    private void applyapplyWindowToViewportTransformation(Graphics2D g2,
                                                          double left, double right, double bottom, double top, 
                                                          boolean preserveAspect) {
        int width = getWidth();   // The width of this drawing area, in pixels.
        int height = getHeight(); // The height of this drawing area, in pixels.
        if (preserveAspect) {
            // Adjust the limits to match the aspect ratio of the drawing area.
            double displayAspect = Math.abs((double)height / width);
            double requestedAspect = Math.abs(( bottom-top ) / ( right-left ));
            if (displayAspect > requestedAspect) {
                // Expand the viewport vertically.
                double excess = (bottom-top) * (displayAspect/requestedAspect - 1);
                bottom += excess/2;
                top -= excess/2;
            }
            else if (displayAspect < requestedAspect) {
                // Expand the viewport vertically.
                double excess = (right-left) * (requestedAspect/displayAspect - 1);
                right += excess/2;
                left -= excess/2;
            }
        }
        g2.scale( width / (right-left), height / (bottom-top) );
        g2.translate( -left, -top );
        double pixelWidth = Math.abs(( right - left ) / width);
        double pixelHeight = Math.abs(( bottom - top ) / height);
        pixelSize = (float)Math.max(pixelWidth,pixelHeight);
    }
    
}
