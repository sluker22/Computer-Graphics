﻿Shannon Luker, Gabby Licht, Reese DelGrande




Walks around a 3D room with interactive and animated elements.


Using WASD walks forward, backward, and side to side


The mouse controls where you look can be around the room, and up and down.


Lighting is displayed that lights up materials and textures of objects


The X key controls the lamp light interactively. You hold down X to shut the lamp light off and release it to turn it back on.