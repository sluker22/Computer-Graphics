#==============================
# Christian Duncan
# CSC345: Computer Graphics
# Spring 2021
# Edited by: Shannon Luker, Gabby Licht, Reese DelGrande
# Description:
#   Demonstrates use of lighting and texture mapping
#   properties to render a 3D room scene.
#==============================

import sys
from utils import *

try:
    import OpenGL as ogl
    try:
        import OpenGL.GL   # this fails in <=2020 versions of Python on OS X 11.x
    except ImportError:
        print('Drat, patching for Big Sur')
        from ctypes import util
        orig_util_find_library = util.find_library
        def new_util_find_library( name ):
            res = orig_util_find_library( name )
            if res: return res
            return '/System/Library/Frameworks/'+name+'.framework/'+name
        util.find_library = new_util_find_library
except ImportError:
    pass

from OpenGL.GLUT import *
from OpenGL.GLU import *
from OpenGL.GL import *
from camera import *
from PIL import Image
import sys
import math

winWidth = 1000
winHeight = 1000

# These parameters define the camera's lens shape
CAM_NEAR = 0.01
CAM_FAR = 1000.0
CAM_ANGLE = 45.0
INITIAL_EYE = Point(0, 5, 10)
INITIAL_LOOK_ANGLE = 0
camera = Camera(CAM_ANGLE, winWidth/winHeight, CAM_NEAR, CAM_FAR, INITIAL_EYE, INITIAL_LOOK_ANGLE)

# These parameters define simple animation properties
FPS = 60.0    # These are good for animation which you would have at some point.
DELAY = int(1000.0 / FPS + 0.5)
brightness = 1   # For dimming the lights (especially on exit)
exiting = False
LPX = -1.5
LPY = 4.5
LPZ = -2

# Global (Module) Variables (ARGH!)
name = b'Interactive 3D Scene'
animate = True

perspectiveMode = True

# Dimensions of the floor (and hence the room)
FLOOR_WIDTH=22   # in feet
FLOOR_DEPTH=28   # in feet
WALL_HEIGHT=10

TABLE_WIDTH = 5
TABLE_DEPTH = 5

PLANE_WIDTH = 14
PLANE_HEIGHT = 5

# Checkerboard dimensions (texture dimensions are powers of 2)
NROWS = 64
NCOLS = 64

size = 8.0

MIN_X_BOUND = -FLOOR_WIDTH/2
MAX_X_BOUND = FLOOR_WIDTH/2
MIN_Z_BOUND = -FLOOR_DEPTH/2
MAX_Z_BOUND = FLOOR_DEPTH/2

eye = Point(0, 10, -70)
look = Point(0, 0, 0)
lookD = Vector(Point(0, 0, -2))
up = Vector(Point(0, 1, 0))  # Usually what you want unless you want a tilted camera

def main():
    # Create the initial window
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH)
    glutInitWindowSize(winWidth, winHeight)
    glutInitWindowPosition(100,100)
    glutCreateWindow(name)

    init()

    # Setup the callback returns for display and keyboard events
    glutDisplayFunc(display)
    glutKeyboardFunc(keyboard)
    glutSpecialFunc(specialKeys)
    glutReshapeFunc(reshape)   # Enable to allow reshaping...
    glutTimerFunc(0, timer, DELAY)

    # Enters the main loop.   
    # Displays the window and starts listening for events.
    glutMainLoop()
    return

# Any initialization material to do...
def init():
    global tube, ball
    tube = gluNewQuadric()
    gluQuadricDrawStyle(tube, GLU_LINE)

    # Generate or load the textures into memory
    generateCheckerBoardTexture()
    loadWoodTexture()
    loadDiceTexture1()
    loadDiceTexture2()
    loadDiceTexture3()
    loadDiceTexture4()
    loadDiceTexture5()
    loadDiceTexture6()


# Callback function used to display the scene
# Currently it just draws a simple polyline (LINE_STRIP)
def display():
    # Set up lighting and depth-test
    glEnable(GL_LIGHTING)
    glEnable(GL_NORMALIZE)    # Inefficient...
    glEnable(GL_DEPTH_TEST)   # For z-buffering!
    glShadeModel(GL_SMOOTH)   # Smooth shading
    glLightModeli(GL_LIGHT_MODEL_LOCAL_VIEWER, GL_TRUE)
    glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_TRUE)

    # Set the viewport to the full screen
    glViewport(0, 0, winWidth, winHeight)

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    # Set view to Perspective Proj. (angle, aspect ratio, near/far planes)
    if perspectiveMode:
        # Set view to Perspective Proj. (angle, aspect ratio, near/far planes)
        gluPerspective(CAM_ANGLE, winWidth/winHeight, CAM_NEAR, CAM_FAR)
    else:
        glOrtho(-winWidth/40, winWidth/40, -winHeight/40, winHeight/40, -100, 100)
    
    # Clear the Screen
    glClearColor(0, 0, 0, 0)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

    # And draw the "Scene"
    glColor3f(1.0, 1.0, 1.0)
    drawScene()

    # And show the scene
    glFlush()
    glutSwapBuffers()  # needed for double buffering!

# Timer: Used to animate the scene when activated:
def timer(alarm):
    glutTimerFunc(0, timer, DELAY)   # Start alarm clock again
    if exiting:
        global brightness
        brightness -= 0.05
        if brightness < 0.01:
            # Enough dimming - terminate!
            glutLeaveMainLoop()
        glutPostRedisplay()

    if animate:
        # Advance to the next frame
        advance()
        glutPostRedisplay()

# Advance the scene one frame
def advance():
    pass

def checkCameraBounds():
    # Check if the camera's eye position is out of bounds
    # and set it inside the bound.
    if camera.eye.x < MIN_X_BOUND:
        camera.eye.x = MIN_X_BOUND
    elif camera.eye.x > MAX_X_BOUND:
        camera.eye.x = MAX_X_BOUND
    elif camera.eye.x < MIN_Z_BOUND:
        camera.eye.x = MIN_Z_BOUND
    elif camera.eye.x > MAX_Z_BOUND:
        camera.eye.x = MAX_Z_BOUND


def specialKeys(key, x, y):
    pass

# Callback function used to handle any key events
# Currently, it just responds to the ESC key (which quits)
# key: ASCII value of the key that was pressed
# x,y: Location of the mouse (in the window) at time of key press)
def keyboard(key, x, y):
    """Process any regular keys that are pressed."""
    global brightness, floor_option, LPX, LPY, LPZ, camera
    if ord(key) == 27:  # ASCII code 27 = ESC-key
        global exiting
        exiting = True
    elif key == b' ':
        global animate
        animate = not animate
    elif key == b'a':
        # Go left
        camera.turn(1)
        glutPostRedisplay()
    elif key == b'd':
        # Go right
        camera.turn(-1)
        glutPostRedisplay()
    elif key == b'w':
        # Go forward
        camera.slide(0, 0, -1)
        checkCameraBounds()
        glutPostRedisplay()
    elif key == b's':
        # Go backward
        camera.slide(0, 0, 1)
        checkCameraBounds()
        glutPostRedisplay()
    elif key == b'q':
        # Go up
        camera.slide(0, 1, 0)
        checkCameraBounds()
        glutPostRedisplay()
    elif key == b'A':
        # Slide left
        camera.slide(-1, 0, 0)
        checkCameraBounds()
        glutPostRedisplay()
    elif key == b'D':
        # Slide right
        camera.slide(1, 0, 0)
        checkCameraBounds()
        glutPostRedisplay()
    elif key == b'e':
        # Go down
        camera.slide(0, -1, 0)
        checkCameraBounds()
        glutPostRedisplay()
    elif key == b'x':
        LPX += 0.1
        glutPostRedisplay()
    elif key == b'X':
        LPX -= 0.1
        glutPostRedisplay()
    elif key == b'y':
        LPY += 0.1
        glutPostRedisplay()
    elif key == b'Y':
        LPY -= 0.1
        glutPostRedisplay()
    elif key == b'z':
        LPZ += 0.1
        glutPostRedisplay()
    elif key == b'Z':
        LPZ -= 0.1
        glutPostRedisplay()
    elif key == b'p':
        print("Light Position: {0} {1} {2}".format(LPX, LPY, LPZ))
        
# Callback function used to handle window reshaping events
def reshape(w, h):
    global winWidth, winHeight
    winWidth = w
    winHeight = h
    glutPostRedisplay()  # May need to call a redraw...

def drawScene():
    """
    * drawScene:
    * Draws a simple scene with a few shapes
    """
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    
    camera.placeCamera()
    
    # Set up the global ambient light.  (Just a little bit here.)
    amb = [ 0.2*brightness, 0.2*brightness, 0.2*brightness, 1.0 ]
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, amb)
    
    place_light0()
    place_light1()
    place_light2()
    place_light3()
    place_light4()

    glColor3f(1, 1, 1)
    drawFloor(FLOOR_WIDTH, FLOOR_DEPTH, checkerBoardName, 100)

    glColor3f(1, 1, 1)
    draw() 

# Draw the entire scene
def draw():
    glPushMatrix()
    # Make the walls and ceiling mimic copper material.
    set_copper(GL_FRONT_AND_BACK) 
    drawCeiling()
    glColor3f(1, 0, 1)

    # The default wall runs from y=0 to y=WALL_HEIGHT and z=0.
    glTranslate(0, 0, -FLOOR_DEPTH/2)
    drawWall(FLOOR_WIDTH, WALL_HEIGHT, FLOOR_DEPTH, woodTextureName, 100)
    glTranslate(FLOOR_WIDTH/2, 0, FLOOR_DEPTH/2)
    glRotated(90, 0, 1, 0)
    drawWall(FLOOR_DEPTH, WALL_HEIGHT, FLOOR_DEPTH, woodTextureName, 100)
    glPopMatrix()

    glPushMatrix()
    # Make the walls and ceiling mimic copper material.
    set_copper(GL_FRONT_AND_BACK) 
    glColor3f(1, 0, 1)
    glTranslate(0, 0, FLOOR_DEPTH/2)
    drawWall(FLOOR_WIDTH, WALL_HEIGHT, FLOOR_DEPTH, woodTextureName, 100)
    glTranslate(-FLOOR_WIDTH/2, 0, -FLOOR_DEPTH/2)
    glRotated(90, 0, 1, 0)
    drawWall(FLOOR_DEPTH, WALL_HEIGHT, FLOOR_DEPTH, woodTextureName, 100)
    glPopMatrix()

    glPushMatrix()
    glTranslate(0, 3, 0)  # Move the table top three feet off the ground.
    # 5x5 foot table that is 0.2 feet (2.4 inches) thick.
    drawTexturedTableTop(5, 5, 0.2, woodTextureName, 50) 
    glPopMatrix()

    #Draws 3D table legs
    glPushMatrix()
    drawTableLegs(0.5, 5, 0.3, woodTextureName, 50)
    glPopMatrix()

    #Draws various items in the room
    glPushMatrix()
    glTranslate(0, 1, 0)
    drawLamp()
    drawBall()
    drawDice()
    glPopMatrix()

def drawFloor(width, height, texture, segments=10):
    """ Draw a textured floor of the specified dimension. """
    glBindTexture(GL_TEXTURE_2D, texture)
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE) # try GL_DECAL/GL_REPLACE/GL_MODULATE
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST)           # try GL_NICEST/GL_FASTEST
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE)  # try GL_CLAMP/GL_REPEAT/GL_CLAMP_TO_EDGE
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR) # try GL_LINEAR/GL_NEAREST
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)

    sx = -width/2
    ex = -sx
    sz = -height/2
    ez = sz
    
    # Enable/Disable each time or OpenGL ALWAYS expects texturing!
    glEnable(GL_TEXTURE_2D)
    cz = sz
    ct = 0
    incz = height/segments
    inct = 1/segments
    for j in range(segments):
        glBegin(GL_QUAD_STRIP)
        cx = sx
        cs = 0
        incx = width/segments
        incs = 1/segments
        glTexCoord2f(cs, ct+inct)
        glVertex3f(cx, 0, cz+incz)
        glTexCoord2f(cs, ct)
        glVertex3f(cx, 0, cz)
        for i in range(segments):
            cx += incx
            cs += incs
            glTexCoord2f(cs, ct+inct)
            glVertex3f(cx, 0, cz+incz)
            glTexCoord2f(cs, ct)
            glVertex3f(cx, 0, cz)
        glEnd()
        cz += incz
        ct += inct
        
    glDisable(GL_TEXTURE_2D)

def drawCeiling():
    glPushMatrix()
    # Make the ceiling mimic copper material.
    set_emerald(GL_FRONT_AND_BACK) 
    glTranslated(0, 8, 0)
    drawFloor(PLANE_WIDTH,PLANE_WIDTH,woodTextureName, 100)
    glPopMatrix()

# Draw a wall that is in the xy plane at z=0 and centered on the y-axis with the bottom part on the x-axis (y=0)
def drawWall(width, height, depth, texture, segments=10):
    glPushMatrix()
    glScale(width, height, 1)

    # Set up the texture properties
    glBindTexture(GL_TEXTURE_2D, texture)
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glEnable(GL_TEXTURE_2D)
        
    # Draw the square
    glTranslated(0, 0.5, -0.5)
    drawTexturedSquare(s=1, t=1, segments=10)  # A little wrapping of the texture
    glPopMatrix()

    glDisable(GL_TEXTURE_2D)

def drawTexturedSquare(s=1, t=1, segments=10):
    z = 0.5   # Keep in in z=0.5 plane.
    sx = -0.5
    ex = 0.5
    sy = -0.5
    ey = -0.5
    cy = sy
    ct = 0
    incy = 1/segments
    inct = t/segments
    incx = 1/segments
    incs = s/segments
    for j in range(segments):
        glBegin(GL_QUAD_STRIP)
        cx = sx
        cs = 0
        glTexCoord2f(cs, ct+inct)
        glVertex3f(cx, cy+incy, z)
        glTexCoord2f(cs, ct)
        glVertex3f(cx, cy, z)
        for i in range(segments):
            cx += incx
            cs += incs
            glTexCoord2f(cs, ct+inct)
            glVertex3f(cx, cy+incy, z)
            glTexCoord2f(cs, ct)
            glVertex3f(cx, cy, z)
        glEnd()
        cy += incy
        ct += inct


def drawTexturedCube(s=1, t=1, segments=10):
    glPushMatrix()
    drawTexturedSquare(s, t, segments) 
    
    glPushMatrix()
    glRotatef(90, 0, 1, 0)
    drawTexturedSquare(s, t, segments)
    glPopMatrix()
    
    glPushMatrix()
    glRotatef(-90, 1, 0, 0)
    drawTexturedSquare(s, t, segments)
    glPopMatrix()
    
    glPushMatrix()
    glRotatef(180, 0, 1, 0)
    drawTexturedSquare(s, t, segments)
    glPopMatrix()
    
    glPushMatrix();
    glRotatef(-90, 0, 1, 0)
    drawTexturedSquare(s, t, segments)
    glPopMatrix()
    
    glPushMatrix()
    glRotatef(90, 1, 0, 0)
    drawTexturedSquare(s, t, segments)
    glPopMatrix()
    
    glPopMatrix() # Restore matrix to its state before cube() was called.
    

def drawTexturedTableTop(width, depth, thickness, texture, segments=10):
    glPushMatrix()
    # Scale the dimensions since the cube is 1x1x1.
    #    Width is in the x, depth in the z, and thickness in the y.
    glScale(width, thickness, depth)

    # Set up the texture properties
    glBindTexture(GL_TEXTURE_2D, texture)
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glEnable(GL_TEXTURE_2D)
        
    # Draw the cube
    drawTexturedCube(s=2, t=2, segments=segments)  # A little wrapping of the texture
    glPopMatrix()

    glDisable(GL_TEXTURE_2D)

def drawTableLegs(width, height, thickness, texture, segments=10):
    glEnable(GL_TEXTURE_2D)   # Enable texturing.  But using whatever texture settings and texture were used LAST.
    
    # Set up the texture properties
    glBindTexture(GL_TEXTURE_2D, texture)
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE)
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
    glEnable(GL_TEXTURE_2D)

    #Leg 1
    glPushMatrix()
    glTranslated(2, 0, 0)
    glScaled(width, height, thickness)
    drawTexturedCube(s=2, t=2, segments=segments)
    glPopMatrix()

    #Leg 2
    glPushMatrix()
    glTranslated(2, 0, -4)
    glScaled(width, height, thickness)
    drawTexturedCube(s=2, t=2, segments=segments)
    glPopMatrix()

    #Leg 3
    glPushMatrix()
    glTranslated(-2, 0, 0)
    glScaled(width, height, thickness)
    drawTexturedCube(s=2, t=2, segments=segments)
    glPopMatrix()

    #Leg 4
    glPushMatrix()
    glTranslated(-2, 0, -4)
    glScaled(width, height, thickness)
    drawTexturedCube(s=2, t=2, segments=segments)
    glPopMatrix()
        
    glDisable(GL_TEXTURE_2D)

def drawLamp():
    #Base
    glPushMatrix()
    glRotated(-90, 1, 0, 0)
    glTranslated(0, 0, 2)
    set_emerald(GL_FRONT_AND_BACK)
    gluCylinder(tube, 0.2, 0.2, 1, 100, 100) # quadric, base r, top r, height (along z), slices (around), stacks (towards height)
    glPopMatrix()

    #Lamp shade
    glPushMatrix()
    glRotated(-90, 1, 0, 0)
    glTranslated(0, 0, 3)
    set_copper(GL_FRONT_AND_BACK)
    gluCylinder(tube, 0.7, 0.1, 0.7, 100, 100) # quadric, base r, top r, height (along z), slices (around), stacks (towards height)
    glPopMatrix()

def drawBall():
    glPushMatrix()
    glTranslated(-1.5, 2.5, -2)
    glScaled(0.5, 0.5, 0.5)
    set_copper(GL_FRONT_AND_BACK)
    glutSolidSphere(1, 10, 10)
    glPopMatrix()

    glPushMatrix()
    glTranslated(0.5, 2.5, -2)
    glScaled(0.5, 0.5, 0.5)
    set_silver(GL_FRONT_AND_BACK)
    glutSolidSphere(1, 10, 10)
    glPopMatrix()

def drawDice():
    glPushMatrix()
    glutSolidCube(0.5);
    glPopMatrix()

    glPushMatrix()
    glTranslated(-1, 0, 1)
    glutSolidCube(0.5);
    glPopMatrix()


def place_light0():
    """Set up light 0."""
    activeLight = GL_LIGHT0
    glMatrixMode(GL_MODELVIEW)
    lx = LPX
    ly = LPY
    lz = LPZ
    lightColor = [0.2, 0.2, 1]
    light_position = [ lx, ly, lz, 1.0 ]
    light_ambient = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_diffuse = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_specular = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_direction = [ 0.0, -1.0, 0.0, 0.0 ]  # Light points down

    # For this light, set position, ambient, diffuse, and specular values
    glLightfv(activeLight, GL_POSITION, light_position)
    glLightfv(activeLight, GL_AMBIENT, light_ambient)
    glLightfv(activeLight, GL_DIFFUSE, light_diffuse)
    glLightfv(activeLight, GL_SPECULAR, light_specular)

    # Constant attenuation (for distance, etc.)
    # Only works for fixed light locations!  Otherwise disabled
    glLightf(activeLight, GL_CONSTANT_ATTENUATION, 1.0)
    glLightf(activeLight, GL_LINEAR_ATTENUATION, 0.0)
    glLightf(activeLight, GL_QUADRATIC_ATTENUATION, 0.000)

    # Create a spotlight effect (none at the moment)
    glLightf(activeLight, GL_SPOT_CUTOFF,40.0)
    glLightf(activeLight, GL_SPOT_EXPONENT, 4.0)
    glLightfv(activeLight, GL_SPOT_DIRECTION, light_direction)
    
    glEnable(activeLight)

    # This part draws a SELF-COLORED sphere (in spot where light is!)
    glPushMatrix()
    glTranslatef(lx,ly,lz)
    glDisable(GL_LIGHTING)
    glColor3fv(lightColor)
    glutSolidSphere(0.2, 20, 20)
    glEnable(GL_LIGHTING)
    glPopMatrix()

def place_light1():
    """Set up light 1."""
    activeLight = GL_LIGHT1
    glMatrixMode(GL_MODELVIEW)
    lx = LPX
    ly = LPY
    lz = LPZ
    lightColor = [0.2, 0.2, 1]
    light_position = [ lx, ly, lz, 1.0 ]
    light_ambient = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_diffuse = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_specular = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_direction = [ 0.0, -1.0, 0.0, 0.0 ]  # Light points down

    # For this light, set position, ambient, diffuse, and specular values
    glLightfv(activeLight, GL_POSITION, light_position)
    glLightfv(activeLight, GL_AMBIENT, light_ambient)
    glLightfv(activeLight, GL_DIFFUSE, light_diffuse)
    glLightfv(activeLight, GL_SPECULAR, light_specular)

    # Constant attenuation (for distance, etc.)
    # Only works for fixed light locations!  Otherwise disabled
    glLightf(activeLight, GL_CONSTANT_ATTENUATION, 1.0)
    glLightf(activeLight, GL_LINEAR_ATTENUATION, 0.0)
    glLightf(activeLight, GL_QUADRATIC_ATTENUATION, 0.000)

    # Create a spotlight effect (none at the moment)
    glLightf(activeLight, GL_SPOT_CUTOFF,40.0)
    glLightf(activeLight, GL_SPOT_EXPONENT, 4.0)
    glLightfv(activeLight, GL_SPOT_DIRECTION, light_direction)
    
    glEnable(activeLight)

    # This part draws a SELF-COLORED sphere (in spot where light is!)
    glPushMatrix()
    glTranslatef(lx+2,ly+2,lz+2)
    glDisable(GL_LIGHTING)
    glColor3fv(lightColor)
    glutSolidSphere(1, 20, 20)
    glEnable(GL_LIGHTING)
    glPopMatrix()

def place_light2():
    """Set up light 2."""
    activeLight = GL_LIGHT2
    glMatrixMode(GL_MODELVIEW)
    lx = 0
    ly = 10
    lz = 0
    lightColor = [0, 1, 0]
    light_position = [ lx, ly, lz, 1.0 ]
    light_ambient = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_diffuse = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_specular = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_direction = [ 0.0, -1.0, 0.0, 0.0 ]  # Light points down

    # For this light, set position, ambient, diffuse, and specular values
    glLightfv(activeLight, GL_POSITION, light_position)
    glLightfv(activeLight, GL_AMBIENT, light_ambient)
    glLightfv(activeLight, GL_DIFFUSE, light_diffuse)
    glLightfv(activeLight, GL_SPECULAR, light_specular)

    # Constant attenuation (for distance, etc.)
    # Only works for fixed light locations!  Otherwise disabled
    glLightf(activeLight, GL_CONSTANT_ATTENUATION, 1.0)
    glLightf(activeLight, GL_LINEAR_ATTENUATION, 0.0)
    glLightf(activeLight, GL_QUADRATIC_ATTENUATION, 0.000)

    # Create a spotlight effect (none at the moment)
    glLightf(activeLight, GL_SPOT_CUTOFF,40.0)
    glLightf(activeLight, GL_SPOT_EXPONENT, 4.0)
    glLightfv(activeLight, GL_SPOT_DIRECTION, light_direction)
    
    glEnable(activeLight)

    # This part draws a SELF-COLORED sphere (in spot where light is!)
    glPushMatrix()
    glTranslatef(lx,ly,lz)
    glDisable(GL_LIGHTING)
    glColor3fv(lightColor)
    glutSolidSphere(0.5, 20, 20)
    glEnable(GL_LIGHTING)
    glPopMatrix()

def place_light3():
    """Set up the light 3."""
    activeLight = GL_LIGHT3
    glMatrixMode(GL_MODELVIEW)
    lx = 5
    ly = 10
    lz = 0
    lightColor = [1, 0, 0]
    light_position = [ lx, ly, lz, 1.0 ]
    light_ambient = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_diffuse = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_specular = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_direction = [ 3.0, -10.0, 0.0, 0.0 ]  # Light points down (and a little to the right)

    # For this light, set position, ambient, diffuse, and specular values
    glLightfv(activeLight, GL_POSITION, light_position)
    glLightfv(activeLight, GL_AMBIENT, light_ambient)
    glLightfv(activeLight, GL_DIFFUSE, light_diffuse)
    glLightfv(activeLight, GL_SPECULAR, light_specular)

    # Constant attenuation (for distance, etc.)
    # Only works for fixed light locations!  Otherwise disabled
    glLightf(activeLight, GL_CONSTANT_ATTENUATION, 1.0)
    glLightf(activeLight, GL_LINEAR_ATTENUATION, 0.0)
    glLightf(activeLight, GL_QUADRATIC_ATTENUATION, 0.000)

    # Create a spotlight effect (none at the moment)
    glLightf(activeLight, GL_SPOT_CUTOFF,20.0)
    glLightf(activeLight, GL_SPOT_EXPONENT, 4.0)
    glLightfv(activeLight, GL_SPOT_DIRECTION, light_direction)
    
    glEnable(activeLight)

    # This part draws a SELF-COLORED sphere (in spot where light is!)
    glPushMatrix()
    glTranslatef(lx,ly,lz)
    glDisable(GL_LIGHTING)
    glColor3fv(lightColor)
    glutSolidSphere(0.5, 20, 20)
    glEnable(GL_LIGHTING)
    glPopMatrix()

def place_light4():
    """Set up the light 4."""
    activeLight = GL_LIGHT4
    glMatrixMode(GL_MODELVIEW)
    lx = -5
    ly = 10
    lz = 0
    lightColor = [0, 0, 1]
    light_position = [ lx, ly, lz, 1.0 ]
    light_ambient = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_diffuse = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_specular = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_direction = [ -3.0, -10.0, 0.0, 0.0 ]  # Light points down

    # For Light 0, set position, ambient, diffuse, and specular values
    glLightfv(activeLight, GL_POSITION, light_position)
    glLightfv(activeLight, GL_AMBIENT, light_ambient)
    glLightfv(activeLight, GL_DIFFUSE, light_diffuse)
    glLightfv(activeLight, GL_SPECULAR, light_specular)

    # Constant attenuation (for distance, etc.)
    # Only works for fixed light locations!  Otherwise disabled
    glLightf(activeLight, GL_CONSTANT_ATTENUATION, 1.0)
    glLightf(activeLight, GL_LINEAR_ATTENUATION, 0.0)
    glLightf(activeLight, GL_QUADRATIC_ATTENUATION, 0.000)

    # Create a spotlight effect (none at the moment)
    glLightf(activeLight, GL_SPOT_CUTOFF,20.0)
    glLightf(activeLight, GL_SPOT_EXPONENT, 4.0)
    glLightfv(activeLight, GL_SPOT_DIRECTION, light_direction)
    
    glEnable(activeLight)

    # This part draws a SELF-COLORED sphere (in spot where light is!)
    glPushMatrix()
    glTranslatef(lx,ly,lz)
    glDisable(GL_LIGHTING)
    glColor3fv(lightColor)
    glutSolidSphere(0.5, 20, 20)
    glEnable(GL_LIGHTING)
    glPopMatrix()

def place_light5():
    """Set up light 5."""
    activeLight = GL_LIGHT5
    glMatrixMode(GL_MODELVIEW)
    lx = 0
    ly = 0
    lz = 3
    lightColor = [0.2, 0.2, 1]
    light_position = [ lx, ly, lz, 1.0 ]
    light_ambient = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_diffuse = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_specular = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_direction = [ 0.0, -1.0, 0.0, 0.0 ]  # Light points down

    # For this light, set position, ambient, diffuse, and specular values
    glLightfv(activeLight, GL_POSITION, light_position)
    glLightfv(activeLight, GL_AMBIENT, light_ambient)
    glLightfv(activeLight, GL_DIFFUSE, light_diffuse)
    glLightfv(activeLight, GL_SPECULAR, light_specular)

    # Constant attenuation (for distance, etc.)
    # Only works for fixed light locations!  Otherwise disabled
    glLightf(activeLight, GL_CONSTANT_ATTENUATION, 1.0)
    glLightf(activeLight, GL_LINEAR_ATTENUATION, 0.0)
    glLightf(activeLight, GL_QUADRATIC_ATTENUATION, 0.000)

    # Create a spotlight effect (none at the moment)
    glLightf(activeLight, GL_SPOT_CUTOFF,40.0)
    glLightf(activeLight, GL_SPOT_EXPONENT, 4.0)
    glLightfv(activeLight, GL_SPOT_DIRECTION, light_direction)
    
    glEnable(activeLight)

    # This part draws a SELF-COLORED sphere (in spot where light is!)
    glPushMatrix()
    glTranslatef(lx+2,ly+2,lz+2)
    glDisable(GL_LIGHTING)
    glColor3fv(lightColor)
    glutSolidSphere(1, 1, 1)
    glEnable(GL_LIGHTING)
    glPopMatrix()

def place_light6():
    """Set up light 6."""
    activeLight = GL_LIGHT6
    glMatrixMode(GL_MODELVIEW)
    lx = LPX
    ly = LPY
    lz = LPZ
    lightColor = [1, 1, 1]
    light_position = [ lx, ly, lz, 1.0 ]
    light_ambient = [ 1*brightness, 1*brightness, 1*brightness, 1.0 ]
    light_diffuse = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_specular = [ lightColor[0]*brightness, lightColor[1]*brightness, lightColor[2]*brightness, 1.0 ]
    light_direction = [ -0.1, 0.0, 0.0, 0.0 ]  #

    # For this light, set position, ambient, diffuse, and specular values
    glLightfv(activeLight, GL_POSITION, light_position)
    glLightfv(activeLight, GL_AMBIENT, light_ambient)
    glLightfv(activeLight, GL_DIFFUSE, light_diffuse)
    glLightfv(activeLight, GL_SPECULAR, light_specular)

    # Constant attenuation (for distance, etc.)
    # Only works for fixed light locations!  Otherwise disabled
    glLightf(activeLight, GL_CONSTANT_ATTENUATION, 1.0)
    glLightf(activeLight, GL_LINEAR_ATTENUATION, 0.0)
    glLightf(activeLight, GL_QUADRATIC_ATTENUATION, 0.000)

    # Create a spotlight effect (none at the moment)
    glLightf(activeLight, GL_SPOT_CUTOFF,40.0)
    glLightf(activeLight, GL_SPOT_EXPONENT, 4.0)
    glLightfv(activeLight, GL_SPOT_DIRECTION, light_direction)
    
    glEnable(activeLight)

    # This part draws a SELF-COLORED sphere (in spot where light is!)
    glPushMatrix()
    glTranslatef(lx+2,ly+2,lz+2)
    glDisable(GL_LIGHTING)
    glColor3fv(lightColor)
    glutSolidSphere(1, 20, 20)
    glEnable(GL_LIGHTING)
    glPopMatrix()

def generateCheckerBoardTexture():
    """
    * Generate a texture in the form of a checkerboard 
    * Why?  Simple to do...
    """
    global checkerBoardName
    global NROWS
    global NCOLS
    texture = [0]*(NROWS*NCOLS*4)
    for i in range(NROWS):
        for j in range(NCOLS):
            c = 0 if ((i&8)^(j&8)) else 255
            idx = (i*NCOLS+j)*4
            texture[idx] = c     # Red
            texture[idx+1] = 0   # Green
            texture[idx+2] = 0   # Blue
            texture[idx+3] = 150 # Alpha (transparency)

    # Generate a "name" for the texture.  
    # Bind this texture as current active texture
    # and sets the parameters for this texture.
    checkerBoardName = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, checkerBoardName)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, NCOLS, NROWS, 0, GL_RGBA,
                 GL_UNSIGNED_BYTE, texture)

def loadWoodTexture():
    global woodTextureName

    # Load the image and crop it to the proper 128x128 (or edit the file!)
    im = Image.open("wood.jpg")
    #print("Wood dimensions: {0}".format(im.size))  # If you want to see the image's original dimensions
    dim = 128
    size = (0,0,dim,dim)
    texture = im.crop(size).tobytes("raw")   # The cropped texture
    
    woodTextureName = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, woodTextureName)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, dim, dim, 0, GL_RGB,
                 GL_UNSIGNED_BYTE, texture)

def loadDiceTexture1():
    global dice1TextureName

    # Load the image and crop it to the proper 128x128 (or edit the file!)
    im = Image.open("dice1.jpg")
    #print("Wood dimensions: {0}".format(im.size))  # If you want to see the image's original dimensions
    dim = 128
    size = (0,0,dim,dim)
    texture = im.crop(size).tobytes("raw")   # The cropped texture
    
    dice1TextureName = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, dice1TextureName)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, dim, dim, 0, GL_RGB,
                 GL_UNSIGNED_BYTE, texture)

def loadDiceTexture2():
    global dice2TextureName

    # Load the image and crop it to the proper 128x128 (or edit the file!)
    im = Image.open("dice2.jpg")
    #print("Wood dimensions: {0}".format(im.size))  # If you want to see the image's original dimensions
    dim = 128
    size = (0,0,dim,dim)
    texture = im.crop(size).tobytes("raw")   # The cropped texture
    
    dice2TextureName = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, dice2TextureName)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, dim, dim, 0, GL_RGB,
                 GL_UNSIGNED_BYTE, texture)

def loadDiceTexture3():
    global dice3TextureName

    # Load the image and crop it to the proper 128x128 (or edit the file!)
    im = Image.open("dice3.jpg")
    #print("Wood dimensions: {0}".format(im.size))  # If you want to see the image's original dimensions
    dim = 128
    size = (0,0,dim,dim)
    texture = im.crop(size).tobytes("raw")   # The cropped texture
    
    dice3TextureName = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, dice3TextureName)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, dim, dim, 0, GL_RGB,
                 GL_UNSIGNED_BYTE, texture)

def loadDiceTexture4():
    global dice4TextureName

    # Load the image and crop it to the proper 128x128 (or edit the file!)
    im = Image.open("dice4.jpg")
    #print("Wood dimensions: {0}".format(im.size))  # If you want to see the image's original dimensions
    dim = 128
    size = (0,0,dim,dim)
    texture = im.crop(size).tobytes("raw")   # The cropped texture
    
    dice4TextureName = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, dice4TextureName)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, dim, dim, 0, GL_RGB,
                 GL_UNSIGNED_BYTE, texture)

def loadDiceTexture5():
    global dice5TextureName

    # Load the image and crop it to the proper 128x128 (or edit the file!)
    im = Image.open("dice5.jpg")
    #print("Wood dimensions: {0}".format(im.size))  # If you want to see the image's original dimensions
    dim = 128
    size = (0,0,dim,dim)
    texture = im.crop(size).tobytes("raw")   # The cropped texture
    
    dice5TextureName = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, dice5TextureName)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, dim, dim, 0, GL_RGB,
                 GL_UNSIGNED_BYTE, texture)

def loadDiceTexture6():
    global dice6TextureName

    # Load the image and crop it to the proper 128x128 (or edit the file!)
    im = Image.open("dice6.jpg")
    #print("Wood dimensions: {0}".format(im.size))  # If you want to see the image's original dimensions
    dim = 128
    size = (0,0,dim,dim)
    texture = im.crop(size).tobytes("raw")   # The cropped texture
    
    dice6TextureName = glGenTextures(1)
    glBindTexture(GL_TEXTURE_2D, dice6TextureName)
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, dim, dim, 0, GL_RGB,
                 GL_UNSIGNED_BYTE, texture)

def set_copper(face):
    """Set the material properties of the given face to "copper"-esque.

    Keyword arguments:
    face -- which face (GL_FRONT, GL_BACK, or GL_FRONT_AND_BACK)
    """
    ambient = [ 0.19125, 0.0735, 0.0225, 1.0 ]
    diffuse = [ 0.7038, 0.27048, 0.0828, 1.0 ]
    specular = [ 0.256777, 0.137622, 0.086014, 1.0 ]
    shininess = 128.0
    glMaterialfv(face, GL_AMBIENT, ambient);
    glMaterialfv(face, GL_DIFFUSE, diffuse);
    glMaterialfv(face, GL_SPECULAR, specular);
    glMaterialf(face, GL_SHININESS, shininess);

def set_silver(face):
    """Set the material properties of the given face to "silver"-esque.

    Keyword arguments:
    face -- which face (GL_FRONT, GL_BACK, or GL_FRONT_AND_BACK)
    """
    ambient = [ 0.19225, 0.19225, 0.19225, 1.0 ]
    diffuse = [ 0.50754, 0.50754, 0.50754, 1.0 ]
    specular = [ 0.508273, 0.508273, 0.508273, 1.0 ]
    shininess = 0.4
    glMaterialfv(face, GL_AMBIENT, ambient);
    glMaterialfv(face, GL_DIFFUSE, diffuse);
    glMaterialfv(face, GL_SPECULAR, specular);
    glMaterialf(face, GL_SHININESS, shininess);

def set_emerald(face):
    """Set the material properties of the given face to "emerald"-esque.

    Keyword arguments:
    face -- which face (GL_FRONT, GL_BACK, or GL_FRONT_AND_BACK)
    """
    ambient = [ 0.0215, 0.1745, 0.0215, 1.0 ]
    diffuse = [ 0.07568, 0.61424, 0.07568, 1.0 ]
    specular = [ 0.633, 0.727811, 0.633, 1.0 ]
    shininess = 0.6
    glMaterialfv(face, GL_AMBIENT, ambient);
    glMaterialfv(face, GL_DIFFUSE, diffuse);
    glMaterialfv(face, GL_SPECULAR, specular);
    glMaterialf(face, GL_SHININESS, shininess);
    
#=======================================
# Direct OpenGL Matrix Operation Examples
#=======================================
def printMatrix():
    """
    Prints out the Current ModelView Matrix
    The problem is in how it is stored in the system
    The matrix is in COL-major versus ROW-major so
    indexing is a bit odd.
    """
    m = glGetFloatv(GL_MODELVIEW_MATRIX)
   
    for row in range(4):
        for col in range(4):
            sys.stdout.write('{0:6.3f} '.format(m[col][row]))
        sys.stdout.write('\n')
    

if __name__ == '__main__': main()
